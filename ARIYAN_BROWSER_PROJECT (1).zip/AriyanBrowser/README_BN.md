# ARIYAN BROWSER — Android Studio Project

Android WebView-ভিত্তিক ব্রাউজার। UI সবুজ নিয়ন (Neon Green) থিমে: Splash, Home, Menu, Downloads, Tabs, Incognito, Settings, লং-প্রেস শিট।

## প্রধান ফিচার
- হোম পেজে নিজস্ব সার্চ বার (ভয়েস ও লেন্স বাটনসহ), Google/YouTube/Facebook/Messenger/WhatsApp/Telegram/X/Instagram শর্টকাট
- একাধিক ট্যাব, ইনকগনিটো, বুকমার্ক, হিস্ট্রি, ডাউনলোড ম্যানেজার, Desktop Mode, Extension ZIP, Ad Blocker
- Light / Dark থিম, English / বাংলা ভাষা, সার্চ ইঞ্জিন বদল
- Settings: General, Privacy & Security, Appearance, Downloads, Notifications, Advanced, Reset to Default

## APK বানানোর নিয়ম
1. ZIP extract করে `AriyanBrowser` ফোল্ডারটি GitHub repository-তে upload করুন।
2. **Actions** ট্যাবে **Build ARIYAN BROWSER APK** workflow চালান।
3. শেষে `ARIYAN-BROWSER-debug-apk` artifact থেকে `app-debug.apk` নামান।

অথবা Android Studio-তে ফোল্ডারটি Open করে **Build > Build APK(s)** দিন।

## নোট
- প্যাকেজ নাম: `com.ariyan.browser` (আগের অ্যাপের উপর আপডেট না হয়ে আলাদা অ্যাপ হিসেবে ইনস্টল হবে)।
- ছবি বদলাতে: `app/src/main/assets/img/portrait.jpg` (স্প্ল্যাশ) ও `face.jpg` (মেনু/About), আইকন: `res/mipmap-xxhdpi/ic_launcher.png`।
- এই পরিবেশে Android SDK নেই, তাই APK বিল্ড করে ফোনে চালানো যায়নি; প্রথম build-এ যাচাই করুন।
